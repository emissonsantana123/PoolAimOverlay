import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'geometry/aim_geometry.dart';

void main() => runApp(const PoolAimApp());

class PoolAimApp extends StatelessWidget {
  const PoolAimApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Pool Aim Overlay Smart',
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: const Color(0xFF0B1115),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF39FF88), brightness: Brightness.dark),
    ),
    home: const AimHome(),
  );
}

class AimHome extends StatefulWidget {
  const AimHome({super.key});
  @override
  State<AimHome> createState() => _AimHomeState();
}

class _AimHomeState extends State<AimHome> {
  double angle = -0.35;
  double length = 1.0;
  double thickness = 2.2;
  int bounces = 2;
  bool showAim = true;
  bool showReflections = true;
  int colorIndex = 0;
  final colors = const [Color(0xFF39FF88), Colors.white, Color(0xFFFF5252)];
  // Coordinates are normalized to the preview: 0..1.
  List<Vec2> corners = [
    const Vec2(.10, .15), const Vec2(.90, .15),
    const Vec2(.90, .83), const Vec2(.10, .83),
  ];
  Vec2 origin = const Vec2(.50, .52);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('POOL AIM OVERLAY'), actions: [
        IconButton(tooltip: 'Calibrar mesa', onPressed: _calibrate, icon: const Icon(Icons.crop_free)),
      ]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          height: 330,
          decoration: BoxDecoration(color: const Color(0xFF111B20), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF26363D))),
          child: ClipRRect(borderRadius: BorderRadius.circular(20), child: CustomPaint(
            painter: TablePainter(corners: corners, origin: origin, angle: angle, lengthFactor: length,
              color: colors[colorIndex], thickness: thickness, drawAim: showAim,
              reflections: showReflections, bounceCount: bounces),
            child: const Center(child: Text('PRÉVIA DA MIRA\\nCalibre os quatro cantos', textAlign: TextAlign.center,
              style: TextStyle(color: Color(0x66FFFFFF), fontWeight: FontWeight.bold))),
          )),
        ),
        const SizedBox(height: 18),
        _switch('Mostrar linha de mira', showAim, (v) => setState(() => showAim = v)),
        _switch('Reflexões nas bordas', showReflections, (v) => setState(() => showReflections = v)),
        _slider('Ângulo', angle, -math.pi, math.pi, (v) => setState(() => angle = v),
          valueText: '${(angle * 180 / math.pi).round()}°'),
        _slider('Comprimento', length, .1, 1.8, (v) => setState(() => length = v),
          valueText: '${(length * 100).round()}%'),
        _slider('Espessura', thickness, 1, 6, (v) => setState(() => thickness = v),
          valueText: thickness.toStringAsFixed(1)),
        _slider('Número máximo de reflexões', bounces.toDouble(), 0, 6,
          (v) => setState(() => bounces = v.round()), valueText: '$bounces'),
        const SizedBox(height: 8),
        Row(children: [
          const Text('Cor da linha'),
          const Spacer(),
          for (var i = 0; i < colors.length; i++)
            IconButton(onPressed: () => setState(() => colorIndex = i),
              icon: Icon(Icons.circle, color: colors[i],
                size: colorIndex == i ? 30 : 23)),
        ]),
        const SizedBox(height: 10),
        FilledButton.icon(onPressed: _calibrate, icon: const Icon(Icons.tune),
          label: const Text('Calibrar os limites da mesa')),
        const SizedBox(height: 10),
        const Text('Esta versão demonstra o desenho e a colisão em uma prévia. Para desenhar sobre o jogo, é necessária integração de sobreposição Android e calibração na tela real.',
          style: TextStyle(color: Colors.white70, height: 1.4)),
      ])),
    );
  }

  Widget _switch(String title, bool value, ValueChanged<bool> onChanged) =>
    SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(title), value: value, onChanged: onChanged);

  Widget _slider(String title, double value, double min, double max, ValueChanged<double> onChanged, {required String valueText}) =>
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(title)), Text(valueText, style: const TextStyle(color: Color(0xFF39FF88)))]),
      Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged),
    ]);

  Future<void> _calibrate() async {
    final result = await Navigator.of(context).push<List<Vec2>>(
      MaterialPageRoute(builder: (_) => CalibrationPage(initial: corners)));
    if (result != null && result.length == 4 && isValidConvexQuad(result)) {
      setState(() {
        corners = result;
        origin = Vec2(
          (result[0].x + result[1].x + result[2].x + result[3].x) / 4,
          (result[0].y + result[1].y + result[2].y + result[3].y) / 4,
        );
      });
    }
  }
}

class CalibrationPage extends StatefulWidget {
  const CalibrationPage({super.key, required this.initial});
  final List<Vec2> initial;
  @override
  State<CalibrationPage> createState() => _CalibrationPageState();
}
class _CalibrationPageState extends State<CalibrationPage> {
  late List<Vec2> points;
  @override
  void initState() { super.initState(); points = [...widget.initial]; }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Calibrar mesa')),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      const Text('Arraste os quatro marcadores para os cantos internos da mesa. A ordem é: superior esquerdo, superior direito, inferior direito, inferior esquerdo.'),
      const SizedBox(height: 14),
      Expanded(child: LayoutBuilder(builder: (context, c) {
        final size = Size(c.maxWidth, c.maxHeight);
        return GestureDetector(
          onPanUpdate: (d) {
            final local = d.localPosition;
            var nearest = 0;
            var best = double.infinity;
            for (var i = 0; i < points.length; i++) {
              final p = Offset(points[i].x * size.width, points[i].y * size.height);
              final dist = (p - local).distance;
              if (dist < best) { best = dist; nearest = i; }
            }
            if (best < 65) {
              setState(() {
                final normalized = Vec2((local.dx / size.width).clamp(0.0, 1.0).toDouble(), (local.dy / size.height).clamp(0.0, 1.0).toDouble());
                points[nearest] = normalized;
              });
            }
          },
          child: CustomPaint(size: size, painter: CalibrationPainter(points)),
        );
      })),
      Text(isValidConvexQuad(points) ? 'Área válida' : 'Atenção: ajuste os pontos para formar um quadrilátero válido',
        style: TextStyle(color: isValidConvexQuad(points) ? const Color(0xFF39FF88) : Colors.orange)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar'))),
        const SizedBox(width: 12),
        Expanded(child: FilledButton(onPressed: isValidConvexQuad(points) ? () => Navigator.pop(context, points) : null,
          child: const Text('Salvar'))),
      ])
    ])),
  );
}

class CalibrationPainter extends CustomPainter {
  CalibrationPainter(this.points);
  final List<Vec2> points;
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path();
    for (var i = 0; i < points.length; i++) {
      final p = Offset(points[i].x * size.width, points[i].y * size.height);
      if (i == 0) { path.moveTo(p.dx, p.dy); } else { path.lineTo(p.dx, p.dy); }
    }
    path.close();
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF111B20));
    canvas.drawPath(path, Paint()..color = const Color(0x3339FF88));
    canvas.drawPath(path, Paint()..color = const Color(0xFF39FF88)..style = PaintingStyle.stroke..strokeWidth = 2);
    for (var i = 0; i < points.length; i++) {
      final p = Offset(points[i].x * size.width, points[i].y * size.height);
      canvas.drawCircle(p, 15, Paint()..color = Colors.black);
      canvas.drawCircle(p, 11, Paint()..color = const Color(0xFF39FF88));
      final tp = TextPainter(text: TextSpan(text: '${i+1}', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, p - Offset(tp.width/2, tp.height/2));
    }
  }
  @override
  bool shouldRepaint(covariant CalibrationPainter oldDelegate) => true;
}

class TablePainter extends CustomPainter {
  TablePainter({required this.corners, required this.origin, required this.angle, required this.lengthFactor,
    required this.color, required this.thickness, required this.drawAim, required this.reflections, required this.bounceCount});
  final List<Vec2> corners; final Vec2 origin; final double angle, lengthFactor, thickness;
  final Color color; final bool drawAim, reflections; final int bounceCount;

  @override
  void paint(Canvas canvas, Size size) {
    final pts = corners.map((p) => Vec2(p.x * size.width, p.y * size.height)).toList();
    final tablePath = Path()..moveTo(pts[0].x, pts[0].y);
    for (var i=1; i<pts.length; i++) { tablePath.lineTo(pts[i].x, pts[i].y); }
    tablePath.close();
    canvas.drawPath(tablePath, Paint()..color = const Color(0xFF164A37));
    canvas.drawPath(tablePath, Paint()..color = const Color(0xFF39FF88)..style = PaintingStyle.stroke..strokeWidth = 2);
    final start = Vec2(origin.x * size.width, origin.y * size.height);
    canvas.drawCircle(Offset(start.x, start.y), 5, Paint()..color = Colors.white);
    if (!drawAim || !isValidConvexQuad(pts)) return;
    final direction = Vec2(math.cos(angle), math.sin(angle));
    final maxLen = size.longestSide * 3 * lengthFactor;
    final segments = traceRayInQuad(start, direction, pts, maxLen: maxLen,
      maxBounces: reflections ? bounceCount : 0);
    final paint = Paint()..color = color.withOpacity(.9)..strokeWidth = thickness..strokeCap = StrokeCap.round;
    for (final s in segments) {
      canvas.drawLine(Offset(s.start.x, s.start.y), Offset(s.end.x, s.end.y), paint);
    }
  }
  @override
  bool shouldRepaint(covariant TablePainter oldDelegate) => true;
}
