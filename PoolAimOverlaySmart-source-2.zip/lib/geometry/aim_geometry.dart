import 'dart:math' as math;

class Vec2 {
  final double x, y;
  const Vec2(this.x, this.y);
  Vec2 operator +(Vec2 b) => Vec2(x+b.x, y+b.y);
  Vec2 operator -(Vec2 b) => Vec2(x-b.x, y-b.y);
  Vec2 operator *(double k) => Vec2(x*k, y*k);
  double dot(Vec2 b) => x*b.x+y*b.y;
  double cross(Vec2 b) => x*b.y-y*b.x;
  double get length => math.sqrt(x*x+y*y);
  Vec2 normalized() { final l=length; return l < 1e-9 ? const Vec2(0,0) : this*(1/l); }
  Vec2 get perpendicular => Vec2(-y,x);
  double distanceTo(Vec2 b) => (this-b).length;
  @override String toString() => 'Vec2($x, $y)';
}
class Segment2 { final Vec2 start,end; const Segment2(this.start,this.end); }

bool isValidConvexQuad(List<Vec2> p) {
  if (p.length != 4) return false;
  double? sign;
  for (var i=0;i<4;i++) {
    final a=p[i], b=p[(i+1)%4], c=p[(i+2)%4];
    final cross=(b-a).cross(c-b);
    if (cross.abs()<1e-5) return false;
    final s=cross.sign;
    if (sign != null && s != sign) return false;
    sign=s;
  }
  // Reject nearly zero area.
  var area=0.0;
  for(var i=0;i<4;i++) area += p[i].cross(p[(i+1)%4]);
  return area.abs() > 1e-3;
}

bool pointInConvexPolygon(Vec2 p, List<Vec2> poly, {double epsilon=1e-7}) {
  if (!isValidConvexQuad(poly)) return false;
  double? sign;
  for (var i=0;i<poly.length;i++) {
    final cross=(poly[(i+1)%poly.length]-poly[i]).cross(p-poly[i]);
    if (cross.abs() <= epsilon) continue;
    if (sign == null) { sign=cross.sign; } else if (cross.sign != sign) return false;
  }
  return true;
}

/// Intersects ray p + t*d with segment a-b. Returns (t,u), where
/// t is ray distance parameter and u is edge interpolation parameter.
({double t,double u,Vec2 point})? _raySegment(Vec2 p, Vec2 d, Vec2 a, Vec2 b) {
  final e=b-a;
  final denom=d.cross(e);
  if (denom.abs()<1e-9) return null;
  final ap=a-p;
  final t=ap.cross(e)/denom;
  final u=ap.cross(d)/denom;
  if (t < 1e-6 || u < -1e-7 || u > 1+1e-7) return null;
  final uu=u.clamp(0.0,1.0);
  return (t:t,u:uu,point:p+d*t);
}

({double t,Vec2 point,int edge})? firstBoundaryHit(Vec2 p, Vec2 direction, List<Vec2> poly) {
  if (!isValidConvexQuad(poly)) return null;
  final d=direction.normalized();
  if (d.length<1e-9) return null;
  ({double t,Vec2 point,int edge})? best;
  for(var i=0;i<poly.length;i++) {
    final hit=_raySegment(p,d,poly[i],poly[(i+1)%poly.length]);
    if(hit==null) continue;
    if(best==null || hit.t<best.t) best=(t:hit.t,point:hit.point,edge:i);
  }
  return best;
}

/// Clips a ray so every rendered point stays inside a convex calibrated table.
/// If origin is outside, returns no segment instead of drawing through the table.
List<Segment2> traceRayInQuad(Vec2 origin, Vec2 direction, List<Vec2> quad,
    {double maxLen=10000, int maxBounces=0}) {
  // Strict safety: invalid table, invalid direction, or origin outside means
  // draw nothing. Never draw a line from outside through the table.
  if (!isValidConvexQuad(quad) || !pointInConvexPolygon(origin, quad, epsilon: 1e-5)) {
    return const [];
  }
  final d0 = direction.normalized();
  if (d0.length < 1e-9 || !maxLen.isFinite || maxLen <= 0) return const [];

  final out = <Segment2>[];
  var p = origin;
  var d = d0;
  var remaining = maxLen;
  final centroid = quad.reduce((a, b) => a + b) * (1 / quad.length);

  for (var bounce = 0; bounce <= maxBounces && remaining > 1e-4; bounce++) {
    final hit = firstBoundaryHit(p, d, quad);
    if (hit == null || !hit.t.isFinite || hit.t <= 1e-6) break;

    final travel = math.min(hit.t, remaining);
    final reachedBoundary = hit.t <= remaining + 1e-7;
    // Use the exact computed edge point when a boundary is reached, avoiding
    // overshoot due to line length or floating-point rounding.
    final end = reachedBoundary ? hit.point : p + d * travel;
    if (!pointInConvexPolygon(end, quad, epsilon: 1e-4)) break;
    out.add(Segment2(p, end));
    remaining -= travel;

    if (!reachedBoundary || bounce == maxBounces || remaining <= 1e-4) break;

    final a = quad[hit.edge];
    final b = quad[(hit.edge + 1) % quad.length];
    final tangent = (b - a).normalized();
    final normal = tangent.perpendicular;
    d = (d - normal * (2 * d.dot(normal))).normalized();
    if (d.length < 1e-9) break;

    // The visible segment ends exactly at the edge. Only the next calculation
    // starts a tiny distance inward to avoid re-hitting the same edge.
    final inward = (centroid - hit.point).normalized();
    p = hit.point + inward * 1e-3;
    remaining -= 1e-3;
    if (!pointInConvexPolygon(p, quad, epsilon: 1e-4)) break;
  }
  return out;
}
