import 'package:flutter_test/flutter_test.dart';
import 'package:pool_aim_overlay_smart/geometry/aim_geometry.dart';

void main() {
  const quad = [Vec2(0,0), Vec2(100,0), Vec2(100,60), Vec2(0,60)];

  test('validates convex table', () {
    expect(isValidConvexQuad(quad), isTrue);
    expect(isValidConvexQuad(const [Vec2(0,0),Vec2(100,60),Vec2(100,0),Vec2(0,60)]), isFalse);
  });

  test('clips ray at right edge', () {
    final s=traceRayInQuad(const Vec2(50,30), const Vec2(1,0), quad, maxLen:1000);
    expect(s, hasLength(1));
    expect(s.first.end.x, closeTo(100, 1e-5));
    expect(s.first.end.y, closeTo(30, 1e-5));
  });

  test('clips ray at top edge', () {
    final s=traceRayInQuad(const Vec2(50,30), const Vec2(0,-1), quad, maxLen:1000);
    expect(s.first.end.x, closeTo(50, 1e-5));
    expect(s.first.end.y, closeTo(0, 1e-5));
  });

  test('does not draw if origin is outside table', () {
    expect(traceRayInQuad(const Vec2(120,30), const Vec2(-1,0), quad), isEmpty);
  });

  test('supports perspective quadrilateral', () {
    const q=[Vec2(10,10),Vec2(90,15),Vec2(82,80),Vec2(15,75)];
    final s=traceRayInQuad(const Vec2(50,40), const Vec2(1,0), q);
    expect(s, isNotEmpty);
    expect(pointInConvexPolygon(s.first.end,q,epsilon:1e-4), isTrue);
  });

  test('reflection creates bounded segments', () {
    final s=traceRayInQuad(const Vec2(50,30), const Vec2(1,.2), quad, maxLen:500, maxBounces:2);
    expect(s.length, lessThanOrEqualTo(3));
    for(final segment in s) {
      expect(pointInConvexPolygon(segment.start,quad,epsilon:1e-3), isTrue);
      expect(pointInConvexPolygon(segment.end,quad,epsilon:1e-3), isTrue);
    }
  });

  test('every segment remains inside calibrated quadrilateral', () {
    const q = [Vec2(10,10), Vec2(90,15), Vec2(82,80), Vec2(15,75)];
    final segments = traceRayInQuad(const Vec2(48,42), const Vec2(1,.13), q,
      maxLen: 1000, maxBounces: 4);
    expect(segments, isNotEmpty);
    for (final segment in segments) {
      expect(pointInConvexPolygon(segment.start, q, epsilon: 1e-4), isTrue);
      expect(pointInConvexPolygon(segment.end, q, epsilon: 1e-4), isTrue);
      // Also check interior points along the rendered segment.
      for (var i = 0; i <= 20; i++) {
        final p = segment.start + (segment.end - segment.start) * (i / 20);
        expect(pointInConvexPolygon(p, q, epsilon: 1e-4), isTrue);
      }
    }
  });

  test('does not render when the starting point is outside the table', () {
    expect(traceRayInQuad(const Vec2(-1, 30), const Vec2(1,0), quad), isEmpty);
  });

}
