package com.example.pool_aim_overlay_smart;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
